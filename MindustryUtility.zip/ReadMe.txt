To customize the name of the project, create a .txt file named "ProjectNameRef.txt" without the quotes.
Type the name of your project into the ProjectNameRef text file on the first line, no white space.
By using a seperate file to save the project name, it will enable an easy-to-track reference across utilies to come.
This is not required. The tasks may be ran one at a time, standalone.
There is currently only one utility task.
(wip)
Created by PipingHotPizza 2021
Version 1.0

PLEASE KEEP THE TOOLKIT INSIDE OF THE MINDUSTRYTOOLKITCONTAINER FOLDER